from .simple_translate import EasyTranslate

__all__ = ['EasyTranslate']
